<?php

const DB_USER = 'root';
const DB_PW   = 'hello';
const DB_SERVER = 'mysql:host=localhost;dbname=dashboard';
